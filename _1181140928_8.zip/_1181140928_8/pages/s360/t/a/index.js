Page({
    data: {},
    onLoad: function(n) {},
    onReady: function() {},
    onShow: function() {
        wx.hideHomeButton({
            complete: function(n) {}
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});