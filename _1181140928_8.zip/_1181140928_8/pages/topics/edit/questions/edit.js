var n = require("../../../../modules/pageCommons.js");

Page({
    data: {},
    onLoad: function(o) {
        n.login(this);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});